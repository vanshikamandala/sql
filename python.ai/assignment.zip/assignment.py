a = 3
b = 5
a -= b
print(a)
a += b
print(a)
a *= b
print(a)
a /=b
print(a)

